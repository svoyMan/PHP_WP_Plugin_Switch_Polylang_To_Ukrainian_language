<div id="message" class="switch-polylang-to-ukrainian-language updated">
	<p><strong><?php _e( 'The "Switch Polylang To Ukrainian language" requires "Popylang" Plugin installed and activated.', 'pstula_domain' ); ?></strong></p>
</div>