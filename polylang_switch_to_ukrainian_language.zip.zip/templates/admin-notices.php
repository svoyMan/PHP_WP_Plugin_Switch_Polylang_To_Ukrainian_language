<div id="message" class="polylang-switch-to-ukrainian-language updated">
	<p><strong><?php _e( 'The "Polylang Switch To Ukrainian language" requires "Popylang" Plugin installed and activated.', 'pstul_domain' ); ?></strong></p>
</div>